					

					Train Dataset
----------------------------------------------------------------
Reflex referring		1-200,943-1142						400
Noun referring			201-350,15,8 						173
Other referring			351-393,900-942,1143-1314			258
It referring			394-520,771-899						256
Noun Phrase referring	521-700								180
Non referring			46,(1306-1377)*2,					190

----------------------------------------------------------------
Total Sentences												1457




					Test Dataset
---------------------------------------------------------
Reflex referring		1-50 						50					
Noun referring			201-250,18 					68
Other referring			351-390						40
It referring			400-450						51
Noun Phrase referring	521-570						50
Non referring			36							36

---------------------------------------------------------
Total Sentences										295