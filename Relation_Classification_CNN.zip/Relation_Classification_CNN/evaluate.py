"""Evaluate the model"""

import argparse
import logging
import os

import torch
import numpy as np
from sklearn.metrics import precision_recall_fscore_support
from sklearn.metrics import accuracy_score

from tools import utils
import model.net as net
from tools.data_loader import DataLoader

from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import roc_curve
from sklearn.metrics import roc_auc_score
import matplotlib.pyplot as plt

parser = argparse.ArgumentParser()
parser.add_argument('--data_dir', default='data/SemEval2010_task8', help="Directory containing the dataset")
parser.add_argument('--embedding_file', default='data/embeddings/vector_50d.txt', help="Embedings file")
parser.add_argument('--model_dir', default='experiments/base_model', help="Directory containing params.json")
parser.add_argument('--gpu', default=0, help="GPU device number, 0 by default, -1 means CPU.")
parser.add_argument('--restore_file', default='best', help="name of the file in --model_dir \
                     containing weights to load")


def evaluate(model, data_iterator, num_steps, metric_labels):
    """Evaluate the model on `num_steps` batches."""
    # set model to evaluation mode
    model.eval()

    output_labels = list()
    target_labels = list()

    # compute metrics over the dataset
    for _ in range(num_steps):
        # fetch the next evaluation batch
        batch_data, batch_labels = next(data_iterator)
        
        # compute model output
        batch_output = model(batch_data)  # batch_size x num_labels
        batch_output_labels = torch.max(batch_output, dim=1)[1]
        output_labels.extend(batch_output_labels.data.cpu().numpy().tolist())
        target_labels.extend(batch_labels.data.cpu().numpy().tolist())

    print("Confusion Matrix")
    print(confusion_matrix(target_labels, output_labels))

    

    # Calculate precision, recall and F1 for all relation categories
    p_r_f1_s = precision_recall_fscore_support(target_labels, output_labels, labels=metric_labels, average='micro')
    p_r_f1 = {'precison': p_r_f1_s[0] * 100,
              'recall': p_r_f1_s[1] * 100,
              'f1': p_r_f1_s[2] * 100}


    x=output_labels
    y=target_labels
    fig, ax = plt.subplots(figsize=(8,8))
    conf_mat = confusion_matrix(y, x)
    labels = ['It','Other','Noun','NounPhrase','Non-referring','Reflex']
    fig = plt.gcf()  # or by other means, like plt.subplots
    figsize = fig.get_size_inches()
    fig.set_size_inches(figsize * 1.5)  # scale current size by 1.5
    sns.heatmap(conf_mat, annot=True, fmt='.0f', cmap="YlGnBu" ,xticklabels=labels, yticklabels=labels).set_title('Confusion Matrix Heat map')
    plt.show()



    """
    x=output_labels
    y=target_labels
    # logistic regression
    model1 = LogisticRegression()
    # knn
    model2 = KNeighborsClassifier(n_neighbors=4)

    # fit model
    model1.fit(x, y)
    model2.fit(x, y)

    # predict probabilities
    pred_prob1 = model1.predict_proba(x)
    pred_prob2 = model2.predict_proba(x)

    # roc curve for models
    fpr1, tpr1, thresh1 = roc_curve(y_test, pred_prob1[:,1], pos_label=1)
    fpr2, tpr2, thresh2 = roc_curve(y_test, pred_prob2[:,1], pos_label=1)

    # roc curve for tpr = fpr 
    random_probs = [0 for i in range(len(y))]
    p_fpr, p_tpr, _ = roc_curve(y, random_probs, pos_label=1)

    # auc scores
    auc_score1 = roc_auc_score(y, pred_prob1[:,1])
    auc_score2 = roc_auc_score(y, pred_prob2[:,1])

    print(auc_score1, auc_score2)

    # plot roc curves
    plt.plot(fpr1, tpr1, linestyle='--',color='orange', label='Logistic Regression')
    plt.plot(fpr2, tpr2, linestyle='--',color='green', label='KNN')
    plt.plot(p_fpr, p_tpr, linestyle='--', color='blue')
    # title
    plt.title('ROC curve')
    # x label
    plt.xlabel('False Positive Rate')
    # y label
    plt.ylabel('True Positive rate')

    plt.legend(loc='best')
    plt.savefig('ROC',dpi=300)
    plt.show();
    """
    """cf_matrix = confusion_matrix(output_labels, target_labels)
    group_names = ['Reflexive','Noun','NounPhrase','Other','It Reference','Non-refering']
    group_counts = ["{0:0.0f}".format(value) for value in cf_matrix.flatten()]
    group_percentages = ["{0:.2%}".format(value) for value in
                     cf_matrix.flatten()/np.sum(cf_matrix)]
    labels = [f"{v1}\n{v2}\n{v3}" for v1, v2, v3 in
          zip(group_names,group_counts,group_percentages)]
    labels = np.asarray(labels)
    sns.heatmap(cf_matrix/np.sum(cf_matrix), annot=True, fmt='.2%', cmap='Blues')
    plt.show()"""

    """cm = confusion_matrix(target_labels, output_labels)
    ax = sns.heatmap(cm, annot=True, fmt='g')
    ax.set_title('Seaborn Confusion Matrix with labels!!')
    ax.set_xlabel('Predicted Fruits')
    ax.set_ylabel('Actual Fruits')
    ax.xaxis.set_ticklabels(['Reflexive','Noun','NounPhrase','Other','It Reference','Non-refering'])
    ax.yaxis.set_ticklabels(['Reflexive','Noun','NounPhrase','Other','It Reference','Non-refering'])
    plt.show()"""
    return p_r_f1

    

if __name__ == '__main__':
    # Load the parameters
    args = parser.parse_args()
    json_path = os.path.join(args.model_dir, 'params.json')
    assert os.path.isfile(json_path), "No json configuration file found at {}".format(json_path)
    params = utils.Params(json_path)

    # Use GPU if available
    params.gpu = -1
    
    # Set the random seed for reproducible experiments
    torch.manual_seed(230)
    if params.gpu >= 0:
        torch.cuda.set_device(params.gpu)
        torch.cuda.manual_seed(230)
        
    # Get the logger
    utils.set_logger(os.path.join(args.model_dir, 'evaluate.log'))

    # Create the input data pipeline
    logging.info("Creating the dataset...")

    # Initialize the DataLoader
    data_loader = DataLoader(data_dir=args.data_dir,
                             embedding_file=args.embedding_file,
                             word_emb_dim=params.word_emb_dim,
                             max_len=params.max_len,
                             pos_dis_limit=params.pos_dis_limit,
                             pad_word='<pad>',
                             unk_word='<unk>',
                             other_label='Other',
                             gpu=params.gpu)
    # Load word embdding
    data_loader.load_embeddings_from_file_and_unique_words(emb_path=args.embedding_file,
                                                           emb_delimiter=' ',
                                                           verbose=True)
    metric_labels = data_loader.metric_labels  # relation labels to be evaluated

    # Load data
    test_data = data_loader.load_data('test')
    test_data_iterator = data_loader.data_iterator(test_data, params.batch_size, shuffle='False')

    # Specify the test set size
    params.test_size = test_data['size']
    num_steps = params.test_size // params.batch_size

    logging.info("- done.")

    # Define the model
    model = net.Net(data_loader, params)

    logging.info("Starting evaluation...")

    # Reload weights from the saved file
    utils.load_checkpoint(os.path.join(args.model_dir, args.restore_file + '.pth.tar'), model)

    # Evaluate
    test_metrics = evaluate(model, test_data_iterator, num_steps, metric_labels)

    metrics_str = "; ".join("{}: {:05.2f}".format(k, v) for k, v in test_metrics.items())
    logging.info("- Test metrics: " + metrics_str)

